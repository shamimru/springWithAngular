package com.example.demo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class StudentDA {

	Connection con;
	PreparedStatement pstm;

	public StudentDA() {
		// TODO Auto-generated constructor stub
	}

//	List<Student> allStudent=new ArrayList<>();

	public List<Student> allStudent() {
		List<Student> sList = new ArrayList<>();

		try {
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/springdb", "root", "root");
			pstm=con.prepareStatement("select * from student");
			ResultSet rs=pstm.executeQuery();
			while (rs.next()) {
				
				sList.add(new Student(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getInt(4)));
				
			}
			
		} catch (Exception e) {
			System.out.println(e);
		}
		return sList;
	}

}
